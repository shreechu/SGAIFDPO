cd $HOME/site/wwwroot
PORT=8080 npx serve -s . -l $PORT